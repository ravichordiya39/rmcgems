<!-- start: Main Menu -->
<div id="sidebar-left" class="span2" style="overflow-y: auto;">
  <div class="nav-collapse sidebar-nav">
    <ul class="nav nav-tabs nav-stacked main-menu">
    <li><a href="dashboard.php"><i class="icon-bar-chart"></i><span class="hidden-tablet"> Dashboard</span></a></li>
    
    <li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Users </span></a>
      <ul>
        <li><a class="submenu" href="users?status=Active"><i class="icon-file-alt"></i><span class="hidden-tablet">Active Users</span></a></li>
        <li><a class="submenu" href="users?status=Pending"><i class="icon-file-alt"></i><span class="hidden-tablet">Pending Users</span></a></li>
         <li><a class="submenu" href="users?status=Suspended"><i class="icon-file-alt"></i><span class="hidden-tablet">Suspended Users</span></a></li>
         <li><a class="submenu" href="users_all"><i class="icon-file-alt"></i><span class="hidden-tablet">All Users</span></a></li>
      </ul>
    </li>
   


    <li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Income history </span></a>      
      <ul> 
		<li><a class="submenu" href="direct-profit-incomes"><i class="icon-file-alt"></i><span class="hidden-tablet">Level Income</span></a></li>   
		 <li><a  href="fund_report?fund_type=car"><i class="icon-file-alt"></i><span class="hidden-tablet">Car Income</span></a></li>
		 <li><a  href="fund_report?fund_type=travel"><i class="icon-file-alt"></i><span class="hidden-tablet">Travel Income</span></a></li>
		 <li><a  href="fund_report?fund_type=company_share"><i class="icon-file-alt"></i><span class="hidden-tablet">Company Share Income</span></a></li>
         </ul>
    </li> 
		
	<li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Product System </span></a>
		<ul>
	 <li> <a class="" href="add_categories"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Categories </span></a>
      
   	 </li>
     <li> <a class="" href="add_sub_categories"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Sub-Categories </span></a>
      
 	  </li>
		<li> <a class="" href="add_products"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Products </span></a>
      
 	  </li>
		<li> <a class="" href="stock-management"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Stock </span></a>
      
 	  </li>
		</ul>
		</li>	
		
	<li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Frenchise System </span></a>
		<ul>
			<li> <a class="" href="fr_users"><i class="icon-folder-close-alt"></i><span class="hidden-tablet">Add Frenchise Users </span></a></li>
			<li> <a class="" href="fr_users_history"><i class="icon-folder-close-alt"></i><span class="hidden-tablet">Frenchise Users </span></a></li>
			<li> <a class="" href="active_fr_users"><i class="icon-folder-close-alt"></i><span class="hidden-tablet">Active Fr Users </span></a></li>
			<li> <a class="" href="suspended_fr_users"><i class="icon-folder-close-alt"></i><span class="hidden-tablet">Suspended Fr Users </span></a></li>
	 		
		</ul>
		</li>
		<li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Frenchise Product </span></a>
		<ul>
		<li> <a class="" href="fr-stock-management"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Products </span></a>
         	 </li>
		</ul>
		</li>
		
	
		<li> <a class="dropmenu" href="order_history"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Order History </span></a>
		<ul>
         <li><a  href="order_history?status=Pending"><i class="icon-file-alt"></i><span class="hidden-tablet">Pending</span></a></li>
         <li><a  href="order_history?status=Rejected"><i class="icon-file-alt"></i><span class="hidden-tablet">Rejected</span></a></li>
         <li><a  href="order_history?status=Approved"><i class="icon-file-alt"></i><span class="hidden-tablet">Approved</span></a></li>
	  </ul>
		
		</li>
	<!--<li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Fund History </span></a>
    <ul>
         <li><a  href="fund_history"><i class="icon-file-alt"></i><span class="hidden-tablet">Fund History</span></a></li>
        
    </ul>
   </li>	-->
   <li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Add bank Details </span></a>
    <ul>
         <li><a  href="add_bank"><i class="icon-file-alt"></i><span class="hidden-tablet">Add Bank</span></a></li>
        
    </ul>
   </li>
   	
   <li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Payments </span></a>
    <ul>
         <li><a  href="waiting_request_payments"><i class="icon-file-alt"></i><span class="hidden-tablet">Waiting Request Payments</span></a></li>
		 <li><a  href="approved_request_payments"><i class="icon-file-alt"></i><span class="hidden-tablet">Approved Request Payments</span></a></li>
		 <li><a  href="rejected_request_payments"><i class="icon-file-alt"></i><span class="hidden-tablet">Rejected Request Payments</span></a></li>
        
    </ul>
   </li>


		<li> <a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> Settings </span></a>
    <ul>
         <li><a  href="event_image"><i class="icon-file-alt"></i><span class="hidden-tablet">Banner Image</span></a></li>
         <li><a  href="dashboard-img"><i class="icon-file-alt"></i><span class="hidden-tablet">Dashboard Image</span></a></li>
        
    </ul>
   </li>

  </div>
</div>
<!-- end: Main Menu -->